<!-- Import layout(fungsi include) -->

<!-- START DATA -->
<?php $__env->startSection('konten'); ?>
<div class="container-fluid">

    <div class="container">
      <!-- Title -->
      <div class="d-flex justify-content-between align-items-lg-center py-3 flex-column flex-lg-row">
        <h2 class="h5 mb-3 mb-lg-0"><a href="../../pages/admin/customers.html" class="text-muted"><i class="bi bi-arrow-left-square me-2"></i></a> Create new customer</h2>
        <div class="hstack gap-3">
            <a href='<?php echo e(url('/tukangsewa/sewa')); ?>'  class= "btn btn-light btn-sm btn-icon-text">Cancel</a>
          <button form="formSewa" class="btn btn-primary btn-sm btn-icon-text"><i class="bi bi-save"></i> <span class="text">Save</span></button>
        </div>
      </div>
      <?php $__currentLoopData = $detailsewa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <!-- Main content -->
      <div class="row">
        <!-- Left side -->
        <div class="col-lg-8">
          <!-- Basic information -->
          <div class="card mb-4">
            <div class="card-body">
              <h3 class="h6 mb-4">Pengaju Sewa</h3>
              <div class="row">
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label class="form-label">Name</label>
                    <div type="text" class="form-control" ><?php echo e($item->name); ?></div>
                  </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3">
                      <label class="form-label">Email</label>
                      <div type="text" class="form-control" ><?php echo e($item->email); ?></div>
                    </div>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label class="form-label">Nomer Telepon</label>
                    <div type="text" class="form-control" ><?php echo e($item->nomer_tlp); ?></div>
                  </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3">
                      <label class="form-label">Nomer SIM</label>
                      <div type="text" class="form-control" ><?php echo e($item->nomer_sim); ?></div>
                    </div>
                </div>
              </div>
              <div class="row">
                <div class="">
                  <div class="mb-3">
                    <label class="form-label">Alamat</label>
                    <div type="text" class="form-control" ><?php echo e($item->alamat); ?></div>
                  </div>
                </div>
              </div>

            </div>
          </div>
          <!-- Address -->
          <div class="card mb-4">
            <div class="card-body">
              <h3 class="h6 mb-4">Mobil yang Ajukan</h3>

              <div class="row">
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label class="form-label">kode mobil</label>
                    <div type="text" class="form-control" ><?php echo e($item->kodemobil); ?></div>
                  </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3">
                      <label class="form-label">Nomer Plat</label>
                      <div type="text" class="form-control" ><?php echo e($item->nomerplat); ?></div>
                    </div>
                </div>
              </div>
              <div class="mb-3">
                <label class="form-label">Model Mobil</label>
                <div type="text" class="form-control" ><?php echo e($item->modelmobil); ?></div>
              </div>
              <div class="mb-3">
                <label class="form-label">Merek Mobil</label>
                <div type="text" class="form-control" ><?php echo e($item->merekmobil); ?></div>
              </div>
              <div class="row">
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label class="form-label">Tarif Sewa Harian</label>
                    <div type="text" class="form-control" ><?php echo e($item->sewaperhari); ?></div>
                  </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3">
                      <label class="form-label">Total Hari</label>
                      <div type="text" class="form-control" ><?php echo e($item->total_hari); ?></div>
                    </div>
                </div>
              </div>
              <div class="mb-3">
                <label class="form-label">Total Bayar</label>
                <div type="text" class="form-control" ><?php echo e($item->totalbayar); ?></div>
              </div>
            </div>
          </div>
        </div>
        <!-- Right side -->
        <div class="col-lg-4">
        <form id='formSewa' action="<?php echo e(url('/tukangsewa/sewa/statusedit/'.$item->id)); ?>" method="POST" >
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
          <!-- Status -->
          <div class="card mb-4">
            <div class="card-body">
              <h3 class="h6">Status</h3>
              <select class="form-select" name="status" required>
                <option value="<?php echo e($item->status); ?>" selected><?php echo e($item->status); ?></option>
                <option value="Pengajuan">Pengajuan</option>
                <option value="Disewakan">Disewakan</option>
                <option value="Tolak">Tolak Ajuan</option>
                <option value="Selesai">Selesai</option>
              </select>
            </div>
          </div>

          <!-- Avatar -->
          <div class="card mb-4">
            <div class="card-body">
              <h3 class="h6">Avatar</h3>
              <input class="form-control" type="file">
            </div>
          </div>
          <!-- Notes -->
          <div class="card mb-4">
            <div class="card-body">
              <h3 class="h6">Notes</h3>
              <textarea class="form-control" name="note" placeholder="<?php echo e($item->note); ?>" rows="3"></textarea>
            </div>
          </div>
        </form>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel\CodingTest\Rental-Mobil\resources\views/tukangsewa/detailsewa.blade.php ENDPATH**/ ?>
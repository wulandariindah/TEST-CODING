<!-- Import layout(fungsi include) -->

<!-- START DATA -->
<?php $__env->startSection('konten'); ?>
<div class="my-3 p-4 bg-body rounded shadow-sm">
    <!-- FORM PENCARIAN -->
    <div class="pb-3">
      <form class="d-flex" action="" method="get">
          <input class="form-control me-1" type="search" name="katakunci" value="<?php echo e(Request::get('katakunci')); ?>" placeholder="Masukkan kata kunci" aria-label="Search">
          <button class="btn btn-secondary" type="submit">Cari</button>
      </form>
    </div>
    <!-- TOMBOL TAMBAH DATA -->
    <table class="table table-striped">
        <thead>
            <tr>
                <th class="col-md-2">UserID</th>
                <th class="col-md-2">Kode mobil</th>
                <th class="col-md-2">Dari Tanggal</th>
                <th class="col-md-2">Sampai Tanggal</th>
                <th class="col-md-2">Jumlah Hari</th>
                <th class="col-md-2">Status</th>

            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $showsewa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->user_id); ?></td>
                <td><?php echo e($item->kodemobil); ?></td>
                <td><?php echo e($item->tanggal_mulai); ?></td>
                <td><?php echo e($item->tanggal_kembali); ?></td>
                <td><?php echo e($item->total_hari); ?></td>
                <td><?php echo e($item->status); ?></td>
                <td>
                    <?php if($item->status === 'Tolak' ): ?>
                    <form onsubmit="return confirm ('yakin mau hapus data?')" class="d-inline" action="<?php echo e(url('/penyewa/delete_sewa/'.$item-> id)); ?>"
                        method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                    <button type="submit" name="submit"  class="btn btn-danger btn-sm"> Hapus</button>
                    </form>
                    <?php endif; ?>
                </td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


</div>
<!-- AKHIR DATA -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel\CodingTest\Rental-Mobil\resources\views/penyewa/pengajuan.blade.php ENDPATH**/ ?>
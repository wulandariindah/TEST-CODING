<!-- Import layout(fungsi include) -->

<!-- START FORM -->
<?php $__env->startSection('konten'); ?>

<form action='<?php echo e(url('admin/tukangsewa')); ?>' method='POST'>
<?php echo csrf_field(); ?>
    <div class="my-3 p-3 bg-body rounded shadow-sm">
        <div class="mb-3 row">
            <label for="nim" class="col-sm-2 col-form-label">Kode Mobil</label>
            <div class="col-sm-10">
                <input type="number" class="form-control" name='kodemobil' value="<?php echo e(Session::get('kodemobil')); ?>" id="kodemobil" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="nama" class="col-sm-2 col-form-label">Merek Mobil</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='merekmobil'  value="<?php echo e(Session::get('merekmobil')); ?>" id="merekmobil" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="jurusan" class="col-sm-2 col-form-label">Model Mobil</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='modelmobil'  value="<?php echo e(Session::get('modelmobil')); ?>" id="modelmobil" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="jurusan" class="col-sm-2 col-form-label">Nomer Plat</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='nomerplat'  value="<?php echo e(Session::get('nomerplat')); ?>" id="nomerplat" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="jurusan" class="col-sm-2 col-form-label">Tarif Per Jam</label>
            <div class="col-sm-10">
                <input type="number" class="form-control" name='tarif'  value="<?php echo e(Session::get('tarif')); ?>" id="tarif" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="status" class="col-sm-2 col-form-label">Status</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='status'  value="Tersedia" id="status" required readonly>
            </div>
        </div>
        <div class="mb-3 row">
            <div class="col-sm-10"><button type="submit" class="btn btn-primary" name="submit">SIMPAN</button>
                <a href='<?php echo e(url('admin/tukangsewa')); ?>'  class= "btn btn-secondary">Cancel</a>
            </div>
        </div>
      </form>
    </div>
    <!-- AKHIR FORM -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel\CodingTest\Rental-Mobil\resources\views/tukangsewa/create.blade.php ENDPATH**/ ?>
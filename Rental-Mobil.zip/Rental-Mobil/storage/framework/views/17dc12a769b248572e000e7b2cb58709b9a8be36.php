<!-- Import layout(fungsi include) -->

<!-- START DATA -->
<?php $__env->startSection('konten'); ?>
<div class="my-3 p-4 bg-body rounded shadow-sm">
    <!-- FORM PENCARIAN -->
    <div class="pb-3">
      <form class="d-flex" action="" method="get">
          <input class="form-control me-1" type="search" name="katakunci" value="<?php echo e(Request::get('katakunci')); ?>" placeholder="Masukkan kata kunci" aria-label="Search">
          <button class="btn btn-secondary" type="submit">Cari</button>
      </form>
    </div>
    <!-- TOMBOL TAMBAH DATA -->
    <div class="pb-3">
      <a href='<?php echo e(url('admin/tukangsewa/create')); ?>' class="btn btn-primary">+ Tambah Data</a>
    </div>
    <table class="table table-striped">
        <thead>
            <tr>
                <th class="col-md-2">Kode mobil</th>
                <th class="col-md-2">Merek Mobil</th>
                <th class="col-md-2">Model Mobil</th>
                <th class="col-md-2">Nomer Plat</th>
                <th class="col-md-2">Tarif</th>
                <th class="col-md-2">Status</th>
                <th class="col-md-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $showmobil->firstItem() ?>
            <?php $__currentLoopData = $showmobil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->kodemobil); ?></td>
                <td><?php echo e($item->merekmobil); ?></td>
                <td><?php echo e($item->modelmobil); ?></td>
                <td><?php echo e($item->nomerplat); ?></td>
                <td><?php echo e($item->tarif); ?></td>
                <td><?php echo e($item->status); ?></td>
                <td>
                    <a href='<?php echo e(url('admin/tukangsewa/'.$item-> kodemobil.'/edit')); ?>' class="btn btn-warning btn-sm">Edit</a>
                    <form onsubmit="return confirm ('yakin mau hapus data?')" class="d-inline" action="<?php echo e(url('admin/tukangsewa/'.$item-> kodemobil)); ?>"
                        method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                    <button type="submit" name="submit"  class="btn btn-danger btn-sm"> Del</button>
                    </form>
                </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($showmobil->links()); ?>



</div>
<!-- AKHIR DATA -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel\CodingTest\Rental-Mobil\resources\views/tukangsewa/index.blade.php ENDPATH**/ ?>
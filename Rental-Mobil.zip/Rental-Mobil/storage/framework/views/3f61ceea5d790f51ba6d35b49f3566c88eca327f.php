<!-- Import layout(fungsi include) -->

<?php $__env->startSection('konten'); ?>
<div class="container-xl px-4 mt-4">
    <div class="row">
        <div class="col-xl-4">
            <!-- Profile picture card-->
            <div class="card mb-4 mb-xl-0">
                <div class="card-header">Profile Picture</div>
                <div class="card-body text-center">
                    <!-- Profile picture image-->
                    <img class="img-account-profile rounded-circle mb-2" src="http://bootdey.com/img/Content/avatar/avatar1.png" alt="">
                    <!-- Profile picture help block-->
                    <div class="small font-italic text-muted mb-4">JPG or PNG no larger than 5 MB</div>
                    <!-- Profile picture upload button-->
                    <button class="btn btn-primary" type="button">Upload new image</button>
                </div>
            </div>

            <div class="card mb-4 mb-xl-0 mt-4 ">
                <div class="card-header">Profile Picture</div>
                <div class="card-header">
                    <form action='<?php echo e(url('editpass/'.$profile->id)); ?>' method='post'>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                    <div class="row gx-3 mb-3">
                        <div class="mb-3">
                            <label class="small mb-1" >Role</label>
                            <div class="form-control"><?php echo e($profile->role); ?>  </div>
                        </div>
                        <div class="mb-3">
                            <label class="small mb-1" >New Password</label>
                            <input class="form-control" name='password' type="text" placeholder="Ganti Password" >
                        </div>
                        <button class="btn btn-primary"  type="submit">Save new password</button>
                    </div>
                </form>
                </div>
            </div>

        </div>

        <div class="col-xl-8">
            <!-- Account details card-->
            <div class="card mb-4">
                <div class="card-header">Account Details</div>
                <div class="card-body">
                    <form action='<?php echo e(url('editprofile/'.$profile->id)); ?>' method='post'>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <!-- Form Group (username)-->
                        <div class="mb-3">
                            <label class="small mb-1" >Nama</label>
                            <input class="form-control" type="text" name='name' placeholder="Nama Anda" value="<?php echo e($profile->name); ?>" >
                        </div>
                        <div class="row gx-3 mb-3">
                            <div class="col-md-6">
                                <label class="small mb-1" >Email</label>
                                <input class="form-control" name='email' type="email" placeholder="name@example.com" value="<?php echo e($profile->email); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="small mb-1" >Nomer Telepon</label>
                                <input class="form-control" name='nomer_tlp' type="number" placeholder="08-"  value="<?php echo e($profile->nomer_tlp); ?>">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="small mb-1" >Alamat</label>
                            <input class="form-control" name='alamat' type="text" placeholder="Alamat" value="<?php echo e($profile->alamat); ?>">
                        </div>
                        <div class="mb-3">
                            <label class="small mb-1" >Nomer SIM</label>
                            <input class="form-control" name='nomer_sim' type="number" placeholder="Nomer SIM" value="<?php echo e($profile->nomer_sim); ?>">
                        </div>
                        <button class="btn btn-primary"  type="submit">Save changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rachm\OneDrive\Dokumen\wulan\Rental-Mobil\resources\views/profil/profile.blade.php ENDPATH**/ ?>
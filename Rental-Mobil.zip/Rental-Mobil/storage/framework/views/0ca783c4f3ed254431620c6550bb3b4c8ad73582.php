
<nav class="nav  d-flex flex-wrap  py-3 mb-4 border-bottom">

   
    <?php if(Auth::user()->role =='tukangsewa'): ?>
    <a class="nav-link active ms-0" href="/profile" >Profile</a>
    <a class="nav-link" href="/admin/tukangsewa" >Data Mobil</a>
    <a class="nav-link me-md-auto" href="/tukangsewa/sewa" >Pengajuan</a>
    <?php endif; ?>
    <?php if(Auth::user()->role =='penyewa'): ?>
    <a class="nav-link active ms-0" href="/profile" >Profile</a>
    <a class="nav-link" href="/admin/penyewa" >List Mobil</a>
    <a class="nav-link"  href="/penyewa/sewa" >Pengajuan</a>
    <a class="nav-link me-md-auto"  href="/penyewa/selesai" >pengembalian</a>
    <?php endif; ?>

<ul class="nav nav-pills ">
    <li class="nav-item"><a href="/logout" class="nav-link">Logout</a></li>
</ul>
</nav>
<?php /**PATH C:\Users\rachm\OneDrive\Dokumen\wulan\Rental-Mobil\resources\views/komponen/menu.blade.php ENDPATH**/ ?>
<!-- Import layout(fungsi include) -->

<!-- START DATA -->
<?php $__env->startSection('konten'); ?>
<div class="my-3 p-4 bg-body rounded shadow-sm">
    <table class="table table-striped">
        <thead>
            <tr>
                <th class="col-md-3">Nama</th>
                <th class="col-md-3">Email</th>
                <th class="col-md-1">Role</th>
                <th class="col-md-3">Alamat</th>
                <th class="col-md-2">Nomer Telepon</th>
                <th class="col-md-4">Nomer SIM</th>
                <th class="col-md-5">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->email); ?></td>
                <td><?php echo e($item->role); ?></td>
                <td><?php echo e($item->alamat); ?></td>
                <td><?php echo e($item->nomer_tlp); ?></td>
                <td><?php echo e($item->nomer_sim); ?></td>
                <td>
                    <?php if($item->id !== 1): ?>
                    <form onsubmit="return confirm ('yakin mau hapus data?')" class="d-inline" action="<?php echo e(url('/admin/operator/'.$item-> nomer_tlp)); ?>"
                        method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                    <button type="submit" name="submit"  class="btn btn-danger btn-sm"> Del</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>
    </table>

</div>
<!-- AKHIR DATA -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel\CodingTest\Rental-Mobil\resources\views/operator/index.blade.php ENDPATH**/ ?>
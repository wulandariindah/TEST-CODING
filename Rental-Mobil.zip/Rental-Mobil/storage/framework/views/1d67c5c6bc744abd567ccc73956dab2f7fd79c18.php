<!-- Import layout(fungsi include) -->

<!-- START DATA -->
<?php $__env->startSection('konten'); ?>
<div class="my-3 p-4 bg-body rounded shadow-sm">
    <!-- FORM PENCARIAN -->
    <div class="pb-3">
      <form action="/penyewa/cari" method="GET">
        <label for="start_date">Tanggal Mulai:</label>
        <input type="date" id="start_date" name="start_date">
        <label for="end_date">Tanggal Akhir:</label>
        <input type="date" id="end_date" name="end_date">
        <button type="submit">Cari</button>
        </form></div>
        <div class="pb-3"><form action="/penyewa/cari2" method="GET">
            <input type="text" name="keyword" placeholder="Cari mobil...">
            <button type="submit">Cari</button>
        </form>
    </div>
    <!-- TOMBOL TAMBAH DATA -->
    <table class="table table-striped">
        <thead>
            <tr>
                <th class="col-md-2">Kode mobil</th>
                <th class="col-md-2">Merek Mobil</th>
                <th class="col-md-2">Model Mobil</th>
                <th class="col-md-2">Nomer Plat</th>
                <th class="col-md-2">Tarif</th>
                <th class="col-md-2">Status</th>
                <th class="col-md-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mobils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->kodemobil); ?></td>
                <td><?php echo e($item->merekmobil); ?></td>
                <td><?php echo e($item->modelmobil); ?></td>
                <td><?php echo e($item->nomerplat); ?></td>
                <td><?php echo e($item->tarif); ?></td>
                <td><?php echo e($item->status); ?></td>
                <td>
                    <a href='<?php echo e(url('/penyewa/detailsewa', ['kodemobil' => $item->kodemobil])); ?>' class="btn btn-warning btn-sm">Sewa</a>
                </td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


</div>
<!-- AKHIR DATA -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rachm\OneDrive\Dokumen\wulan\Rental-Mobil\resources\views/penyewa/index.blade.php ENDPATH**/ ?>
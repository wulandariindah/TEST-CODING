<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Data Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link href="../css/profile.css" rel="stylesheet">
    <link href="../css/detailsewa.css" rel="stylesheet">
  </head>
  <body class="bg-light">
    <main class="container">
        <!-- konten -->
        <?php if(Auth::check()): ?>
            <?php echo $__env->make('komponen/menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php echo $__env->make('komponen.pesan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('konten'); ?>
        <!-- AKHIR Konten -->
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8"
        crossorigin="anonymous">
    </script>
    <script>

        function calculateDateDifference() {


                var today = new Date().toISOString().split('T')[0];
                document.getElementById('tanggal_mulai').setAttribute('min',today);
                document.getElementById('tanggal_kembali').setAttribute('min',today);



            var startDate = new Date(document.getElementById('tanggal_mulai').value);
            var endDate = new Date(document.getElementById('tanggal_kembali').value);

            if(startDate > endDate) {
                alert('tanggal kembali harus setelah tanggal mulai.');
                return
            }

            var timeDifference = Math.abs(endDate.getTime() - startDate.getTime() + 1);
            var daysDifference = Math.ceil(timeDifference / (1000 * 3600 * 24));

            var jumlah_hari = document.getElementById('jumlah_hari').value = daysDifference;
            var tarif = document.getElementById('tarif').value;
            var totalbayar = jumlah_hari*tarif;

            document.getElementById('totalbayar').value = totalbayar;

        }
    </script>

  </body>
</html>
<?php /**PATH C:\Users\rachm\OneDrive\Dokumen\wulan\Rental-Mobil\resources\views/layout/template2.blade.php ENDPATH**/ ?>
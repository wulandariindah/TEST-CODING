<!-- Import layout(fungsi include) -->

<!-- START FORM -->
<?php $__env->startSection('konten'); ?>

<form action='<?php echo e(url('admin/tukangsewa/'.$editdata->kodemobil)); ?>' method='post'>
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>

    <div class="my-3 p-3 bg-body rounded shadow-sm">
        <div class="mb-3 row">
            <label for="kodemobil" class="col-sm-2 col-form-label">Kode Mobil</label>
            <div class="col-sm-10">
               <div class="form-control"> <?php echo e($editdata->kodemobil); ?></div>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="merekmobil" class="col-sm-2 col-form-label">Merek Mobil</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='merekmobil' value="<?php echo e($editdata->merekmobil); ?>" id="merekmobil" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="model mobil" class="col-sm-2 col-form-label">Model Mobil</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='modelmobil' value="<?php echo e($editdata->modelmobil); ?>"  id="modelmobil" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="nomerplat" class="col-sm-2 col-form-label">Nomer Plat</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='nomerplat'  value="<?php echo e($editdata->nomerplat); ?>" id="nomerplat" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="tarif" class="col-sm-2 col-form-label">Tarif Per Hari/12 Jam</label>
            <div class="col-sm-10">
                <input type="number" class="form-control" name='tarif'  value="<?php echo e($editdata->tarif); ?>" id="tarif" required>
            </div>
        </div>
        <div class="mb-3">
            <label for="status" class="col-sm-2 col-form-label">Status</label><br />
            <select class="form-control" id="" name="status" required >
                 <option value="<?php echo e($editdata->status); ?>" selected><?php echo e($editdata->status); ?></option>
                <option value="Tersedia">Tersedia</option>
                <option value="Perawatan">Perawatan</option>
            </select>
        </div>
        <div class="mb-3 row">
            <div class="col-sm-10">
                <button type="submit" class="btn btn-primary" name="submit">SIMPAN</button>
                <a href='<?php echo e(url('admin/tukangsewa')); ?>'  class= "btn btn-secondary">Cancel</a>
            </div>
        </div>
      </form>
    </div>
    <!-- AKHIR FORM -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel\CodingTest\Rental-Mobil\resources\views/tukangsewa/edit.blade.php ENDPATH**/ ?>
<!-- Import layout(fungsi include) -->
@extends('layout.template2')
<!-- START FORM -->
@section('konten')

<form action='{{ url('admin/tukangsewa') }}' method='POST'>
@csrf
    <div class="my-3 p-3 bg-body rounded shadow-sm">
        <div class="mb-3 row">
            <label for="nim" class="col-sm-2 col-form-label">Kode Mobil</label>
            <div class="col-sm-10">
                <input type="number" class="form-control" name='kodemobil' value="{{ Session::get('kodemobil') }}" id="kodemobil" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="nama" class="col-sm-2 col-form-label">Merek Mobil</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='merekmobil'  value="{{ Session::get('merekmobil') }}" id="merekmobil" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="jurusan" class="col-sm-2 col-form-label">Model Mobil</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='modelmobil'  value="{{ Session::get('modelmobil') }}" id="modelmobil" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="jurusan" class="col-sm-2 col-form-label">Nomer Plat</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='nomerplat'  value="{{ Session::get('nomerplat') }}" id="nomerplat" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="jurusan" class="col-sm-2 col-form-label">Tarif Per Jam</label>
            <div class="col-sm-10">
                <input type="number" class="form-control" name='tarif'  value="{{ Session::get('tarif') }}" id="tarif" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="status" class="col-sm-2 col-form-label">Status</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='status'  value="Tersedia" id="status" required readonly>
            </div>
        </div>
        <div class="mb-3 row">
            <div class="col-sm-10"><button type="submit" class="btn btn-primary" name="submit">SIMPAN</button>
                <a href='{{ url('admin/tukangsewa') }}'  class= "btn btn-secondary">Cancel</a>
            </div>
        </div>
      </form>
    </div>
    <!-- AKHIR FORM -->

@endsection

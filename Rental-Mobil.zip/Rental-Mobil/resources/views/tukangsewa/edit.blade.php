<!-- Import layout(fungsi include) -->
@extends('layout.template2')
<!-- START FORM -->
@section('konten')

<form action='{{ url('admin/tukangsewa/'.$editdata->kodemobil) }}' method='post'>
    @csrf
    @method('put')

    <div class="my-3 p-3 bg-body rounded shadow-sm">
        <div class="mb-3 row">
            <label for="kodemobil" class="col-sm-2 col-form-label">Kode Mobil</label>
            <div class="col-sm-10">
               <div class="form-control"> {{ $editdata->kodemobil }}</div>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="merekmobil" class="col-sm-2 col-form-label">Merek Mobil</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='merekmobil' value="{{ $editdata->merekmobil }}" id="merekmobil" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="model mobil" class="col-sm-2 col-form-label">Model Mobil</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='modelmobil' value="{{ $editdata->modelmobil }}"  id="modelmobil" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="nomerplat" class="col-sm-2 col-form-label">Nomer Plat</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='nomerplat'  value="{{ $editdata->nomerplat }}" id="nomerplat" required>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="tarif" class="col-sm-2 col-form-label">Tarif Per Hari/12 Jam</label>
            <div class="col-sm-10">
                <input type="number" class="form-control" name='tarif'  value="{{ $editdata->tarif }}" id="tarif" required>
            </div>
        </div>
        <div class="mb-3">
            <label for="status" class="col-sm-2 col-form-label">Status</label><br />
            <select class="form-control" id="" name="status" required >
                 <option value="{{ $editdata->status }}" selected>{{ $editdata->status }}</option>
                <option value="Tersedia">Tersedia</option>
                <option value="Perawatan">Perawatan</option>
            </select>
        </div>
        <div class="mb-3 row">
            <div class="col-sm-10">
                <button type="submit" class="btn btn-primary" name="submit">SIMPAN</button>
                <a href='{{ url('admin/tukangsewa') }}'  class= "btn btn-secondary">Cancel</a>
            </div>
        </div>
      </form>
    </div>
    <!-- AKHIR FORM -->

@endsection

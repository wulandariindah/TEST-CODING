<!-- Import layout(fungsi include) -->
@extends('layout.template2')
<!-- START DATA -->
@section('konten')
<div class="my-3 p-4 bg-body rounded shadow-sm">
    <!-- FORM PENCARIAN -->
    <div class="pb-3">
      <form class="d-flex" action="" method="get">
          <input class="form-control me-1" type="search" name="katakunci" value="{{ Request::get('katakunci') }}" placeholder="Masukkan kata kunci" aria-label="Search">
          <button class="btn btn-secondary" type="submit">Cari</button>
      </form>
    </div>
    <!-- TOMBOL TAMBAH DATA -->
    <table class="table table-striped">
        <thead>
            <tr>
                <th class="col-md-2">UserID</th>
                <th class="col-md-2">Kode mobil</th>
                <th class="col-md-2">Total Hari</th>
                <th class="col-md-2">Tarif Sewa</th>
                <th class="col-md-2">Status</th>
                <th class="col-md-2">Aksi</th>
            </tr>
        </thead>
        <tbody>

            @foreach ($sewa as $item)
            <tr>
                <td>{{$item->user_id }}</td>
                <td>{{$item->kodemobil }}</td>
                <td>{{$item->total_hari }}</td>
                <td>{{$item->sewaperhari }}</td>
                <td>{{$item->status }}</td>
                <td>
                    <a href={{ url('/tukangsewa/detailsewa', ['id' => $item->id]) }} class="btn btn-warning btn-sm">Detail</a>

                </td>
            </tr>

            @endforeach
        </tbody>
    </table>


</div>
<!-- AKHIR DATA -->

@endsection

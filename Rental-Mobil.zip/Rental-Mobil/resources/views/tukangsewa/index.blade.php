<!-- Import layout(fungsi include) -->
@extends('layout.template2')
<!-- START DATA -->
@section('konten')
<div class="my-3 p-4 bg-body rounded shadow-sm">
    <!-- FORM PENCARIAN -->
    <div class="pb-3">
      <form class="d-flex" action="" method="get">
          <input class="form-control me-1" type="search" name="katakunci" value="{{ Request::get('katakunci') }}" placeholder="Masukkan kata kunci" aria-label="Search">
          <button class="btn btn-secondary" type="submit">Cari</button>
      </form>
    </div>
    <!-- TOMBOL TAMBAH DATA -->
    <div class="pb-3">
      <a href='{{ url('admin/tukangsewa/create')}}' class="btn btn-primary">+ Tambah Data</a>
    </div>
    <table class="table table-striped">
        <thead>
            <tr>
                <th class="col-md-2">Kode mobil</th>
                <th class="col-md-2">Merek Mobil</th>
                <th class="col-md-2">Model Mobil</th>
                <th class="col-md-2">Nomer Plat</th>
                <th class="col-md-2">Tarif</th>
                <th class="col-md-2">Status</th>
                <th class="col-md-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $showmobil->firstItem() ?>
            @foreach ($showmobil as $item)
            <tr>
                <td>{{$item->kodemobil }}</td>
                <td>{{$item->merekmobil }}</td>
                <td>{{$item->modelmobil }}</td>
                <td>{{$item->nomerplat }}</td>
                <td>{{$item->tarif }}</td>
                <td>{{$item->status }}</td>
                <td>
                    <a href='{{ url('admin/tukangsewa/'.$item-> kodemobil.'/edit') }}' class="btn btn-warning btn-sm">Edit</a>
                    <form onsubmit="return confirm ('yakin mau hapus data?')" class="d-inline" action="{{ url('admin/tukangsewa/'.$item-> kodemobil) }}"
                        method="POST">
                        @csrf
                        @method('DELETE')
                    <button type="submit" name="submit"  class="btn btn-danger btn-sm"> Del</button>
                    </form>
                </td>
            </tr>

            @endforeach
        </tbody>
    </table>
    {{ $showmobil->links() }}


</div>
<!-- AKHIR DATA -->

@endsection

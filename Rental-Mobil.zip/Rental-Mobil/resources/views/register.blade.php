@extends('layout/template1')

@section('konten')
    <div class="w-50 center border rounded px-3 py-3 mx-auto">
        <h1>Register</h1>
        <form action="/create" method="POST">
            @csrf
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" value="{{ Session::get('name') }}" name="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" value="{{ Session::get('email') }}" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" value="{{ Session::get('password') }}" name="password" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="role" class="form-label">Daftar Sebagai</label><br />
                <select class="form-control" id="" value="{{ Session::get('role') }}" required >
                    <option value="">Pilih Role</option>
                    <option value="tukangsewa">Tukang Sewa</option>
                    <option value="penyewa">Penyewa Mobil</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat</label>
                <input type="text" value="{{ Session::get('alamat') }}"name="alamat" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="nomer_tlp" class="form-label">No Telepon</label>
                <input type="number" value="{{ Session::get('nomer_tlp') }}" name="nomer_tlp" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="nomer_sim" class="form-label">No SIM</label>
                <input type="number" value="{{ Session::get('nomer_sim') }}" name="nomer_sim" class="form-control" required>
            </div>
            <div class="mb-3 d-grid">
                <button name="submit" type="submit" class="btn btn-primary">daftar</button>
            </div>
            <div class="mb-3 d-grid">
                <p> sudah punya akun? silakan login </p>
                <a href="/" class="btn btn-secondary btn-lg">Cancel</a>
              </div>
        </form>
    </div>
@endsection

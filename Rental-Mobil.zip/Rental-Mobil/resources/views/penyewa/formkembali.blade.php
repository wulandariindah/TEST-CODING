<!-- Import layout(fungsi include) -->
@extends('layout.template2')
<!-- START DATA -->
@section('konten')
<div class="container-fluid">

    <div class="container">
      <!-- Title -->
      <div class="d-flex justify-content-between align-items-lg-center py-3 flex-column flex-lg-row">
        <h2 class="h5 mb-3 mb-lg-0"><a href="../../pages/admin/customers.html" class="text-muted"><i class="bi bi-arrow-left-square me-2"></i></a> Create new customer</h2>
        <div class="hstack gap-3">
            <a href='{{ url('/tukangsewa/sewa') }}'  class= "btn btn-light btn-sm btn-icon-text">Cancel</a>
          <button form="formSewa" class="btn btn-primary btn-sm btn-icon-text"><i class="bi bi-save"></i> <span class="text">Save</span></button>
        </div>
      </div>
      @foreach ($detailsewa2 as $item)
      <!-- Main content -->
      <div class="row">
        <!-- Left side -->
        <div class="col-lg-8">
          <!-- Basic information -->
          <div class="card mb-4">
            <div class="card-body">
              <h3 class="h6 mb-4">Pengaju Sewa</h3>
              <div class="row">
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label class="form-label">Name</label>
                    <div type="text" class="form-control" >{{ $item->name }}</div>
                  </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3">
                      <label class="form-label">Email</label>
                      <div type="text" class="form-control" >{{ $item->email }}</div>
                    </div>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label class="form-label">Nomer Telepon</label>
                    <div type="text" class="form-control" >{{ $item->nomer_tlp }}</div>
                  </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3">
                      <label class="form-label">Nomer SIM</label>
                      <div type="text" class="form-control" >{{ $item->nomer_sim }}</div>
                    </div>
                </div>
              </div>
              <div class="row">
                <div class="">
                  <div class="mb-3">
                    <label class="form-label">Alamat</label>
                    <div type="text" class="form-control" >{{ $item->alamat }}</div>
                  </div>
                </div>
              </div>

            </div>
          </div>
          <!-- Address -->
          <div class="card mb-4">
            <div class="card-body">
              <h3 class="h6 mb-4">Mobil yang Ajukan</h3>

              <div class="row">
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label class="form-label">kode mobil</label>
                    <div type="text" class="form-control" >{{ $item->kodemobil }}</div>
                  </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3">
                      <label class="form-label">Nomer Plat</label>
                      <div type="text" class="form-control" >{{ $item->nomerplat }}</div>
                    </div>
                </div>
              </div>
              <div class="mb-3">
                <label class="form-label">Model Mobil</label>
                <div type="text" class="form-control" >{{ $item->modelmobil }}</div>
              </div>
              <div class="mb-3">
                <label class="form-label">Merek Mobil</label>
                <div type="text" class="form-control" >{{ $item->merekmobil }}</div>
              </div>
              <div class="row">
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label class="form-label">Tarif Sewa Harian</label>
                    <div type="text" class="form-control" >{{ $item->sewaperhari }}</div>
                  </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3">
                      <label class="form-label">Total Hari</label>
                      <div type="text" class="form-control" >{{ $item->total_hari }}</div>
                    </div>
                </div>
              </div>
              <div class="mb-3">
                <label class="form-label">Total Bayar</label>
                <div type="text" class="form-control" >{{ $item->totalbayar }}</div>
              </div>
            </div>
          </div>
        </div>
        <!-- Right side -->
        <div class="col-lg-4">
        <form id='formSewa' action="{{ url('/penyewa/kembali/'.$item->id) }}" method="POST" >
            @csrf
            @method('put')
          <!-- Status -->
          <div class="card mb-4">
            <div class="card-body">
              <h3 class="h6">Status</h3>
              <select class="form-select" name="status" required>
                <option value="{{ $item->status }}" selected>{{ $item->status }}</option>
                <option value="Pengembalian">Pengembalian</option>
              </select>
            </div>
          </div>

          <!-- Avatar -->
          <div class="card mb-4">
            <div class="card-body">
              <h3 class="h6">Avatar</h3>
              <input class="form-control" type="file">
            </div>
          </div>
          <!-- Notes -->
          <div class="card mb-4">
            <div class="card-body">
              <h3 class="h6">Notes</h3>
              <textarea class="form-control" name="note" placeholder="{{ $item->note }}" rows="3"></textarea>
            </div>
          </div>
        </form>
        </div>
      </div>
      @endforeach
    </div>

</div>
@endsection

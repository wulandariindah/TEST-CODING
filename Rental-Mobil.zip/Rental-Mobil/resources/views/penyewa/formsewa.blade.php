<!-- Import layout(fungsi include) -->
@extends('layout.template2')
<!-- START DATA -->
@section('konten')
<div class="container-fluid">

    <div class="container">
      <!-- Title -->
      <div class="d-flex justify-content-between align-items-lg-center py-3 flex-column flex-lg-row">
        <h2 class="h5 mb-3 mb-lg-0"><a href="../../pages/admin/customers.html" class="text-muted"><i class="bi bi-arrow-left-square me-2"></i></a> Create new customer</h2>
        <div class="hstack gap-3">
            <a href='{{ url('admin/penyewa') }}'  class= "btn btn-light btn-sm btn-icon-text">Cancel</a>
          <button form="formSewa" class="btn btn-primary btn-sm btn-icon-text"><i class="bi bi-save"></i> <span class="text">Save</span></button>
        </div>
      </div>

      <!-- Main content -->
      <div class="row">
        <!-- Left side -->
        <div class="col-lg-8">
          <!-- Basic information -->
          <form id='formSewa' action="/penyewa/addsewa/'.$item->kodemobil" method="POST" >
            @csrf
          <div class="card mb-4">
            <div class="card-body">
                @foreach ($usersewa as $item)
              <h3 class="h6 mb-4">Pengaju Sewa</h3>
              <div class="row">
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input type="number" name='user_id'  value="{{ $item->id }}" id="id" required  hidden>
                    <div type="text" class="form-control" >{{ $item->name }}</div>
                  </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3">
                      <label class="form-label">Email</label>
                      <div type="text" class="form-control" >{{ $item->email }}</div>
                    </div>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label class="form-label">Nomer Telepon</label>
                    <div type="text" class="form-control" >{{ $item->nomer_tlp }}</div>
                  </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3">
                      <label class="form-label">Nomer SIM</label>
                      <div type="text" class="form-control" >{{ $item->nomer_sim }}</div>
                    </div>
                </div>
              </div>
              <div class="row">
                <div class="">
                  <div class="mb-3">
                    <label class="form-label">Alamat</label>
                    <div type="text" class="form-control" >{{ $item->alamat }}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          @endforeach
          <!-- Address -->

          <div class="card mb-4">
            <div class="card-body">
              <h3 class="h6 mb-4">Mobil yang Ajukan</h3>
              <div class="row">
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label class="form-label">kode mobil</label>
                    <input type="number" class="form-control" name="kodemobil"  value="{{ $mobilsewa->kodemobil }}" id="kodemobil" readonly>
                  </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3">
                      <label class="form-label">Nomer Plat</label>
                      <div type="text" class="form-control" >{{ $mobilsewa->nomerplat }}</div>
                    </div>
                </div>
              </div>
              <div class="mb-3">
                <label class="form-label">Model Mobil</label>
                <div type="text" class="form-control" >{{ $mobilsewa->modelmobil }}</div>
              </div>
              <div class="mb-3">
                <label class="form-label">Merek Mobil</label>
                <div type="text" class="form-control" >{{ $mobilsewa->merekmobil }}</div>
              </div>
              <div class="row">
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label class="form-label">Tanggal Mulai</label>
                    <input class="form-control" type="date" id="tanggal_mulai" name="tanggal_mulai" onchange="calculateDateDifference()" required>
                  </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3">
                      <label class="form-label">Tanggal Kembali</label>
                      <input class="form-control" type="date" id="tanggal_kembali" name="tanggal_kembali" onchange="calculateDateDifference()" required>
                    </div>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label class="form-label">Tarif Sewa Harian</label>
                    <input type="number" class="form-control" name='sewaperhari'  value="{{ $mobilsewa->tarif }}" id="tarif" onchange="calculateDateDifference()" readonly>
                  </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3">
                      <label class="form-label">Total Hari</label>
                      <input class="form-control" type="text" id="jumlah_hari" name="total_hari" onchange="calculateDateDifference()" readonly>
                    </div>
                </div>
              </div>
              <div class="mb-3">
                <label class="form-label">Total Bayar</label>
                <input type="number" class="form-control" name='totalbayar'  value="" id="totalbayar" onchange="calculateDateDifference()" readonly>
              </div>
            </div>
          </div>
        </div>

        <!-- Right side -->
        <div class="col-lg-4">

          <!-- Status -->
          <div class="card mb-4">
            <div class="card-body">
              <h3 class="h6">Status</h3>
              <input type="text" class="form-control" name='status'  placeholder="Pengajuan" value="Pengajuan" id= "status" readonly>
            </div>

          </div>
          <!-- Avatar -->
          <div class="card mb-4">
            <div class="card-body">
              <h3 class="h6">Avatar</h3>
              <input class="form-control" type="file">
            </div>
          </div>
          <!-- Notes -->
          <div class="card mb-4">
            <div class="card-body">
              <h3 class="h6">Notes</h3>
              <textarea class="form-control" name='note' id= "note"  rows="3"></textarea>
            </div>
          </div>
        </form>
        </div>
      </div>

    </div>

</div>
@endsection

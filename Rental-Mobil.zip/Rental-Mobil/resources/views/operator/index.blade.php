<!-- Import layout(fungsi include) -->
@extends('layout.template2')
<!-- START DATA -->
@section('konten')
<div class="my-3 p-4 bg-body rounded shadow-sm">
    <table class="table table-striped">
        <thead>
            <tr>
                <th class="col-md-3">Nama</th>
                <th class="col-md-3">Email</th>
                <th class="col-md-1">Role</th>
                <th class="col-md-3">Alamat</th>
                <th class="col-md-2">Nomer Telepon</th>
                <th class="col-md-4">Nomer SIM</th>
                <th class="col-md-5">Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($show as $item)
            <tr>
                <td>{{$item->name }}</td>
                <td>{{$item->email }}</td>
                <td>{{$item->role }}</td>
                <td>{{$item->alamat }}</td>
                <td>{{$item->nomer_tlp }}</td>
                <td>{{$item->nomer_sim }}</td>
                <td>
                    @if ($item->id !== 1)
                    <form onsubmit="return confirm ('yakin mau hapus data?')" class="d-inline"
                    action="{{ url('/admin/operator/'.$item-> nomer_tlp) }}"
                        method="POST">
                        @csrf
                        @method('DELETE')
                    <button type="submit" name="submit"  class="btn btn-danger btn-sm"> Del</button>
                    </form>
                    @endif
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

</div>
<!-- AKHIR DATA -->

@endsection

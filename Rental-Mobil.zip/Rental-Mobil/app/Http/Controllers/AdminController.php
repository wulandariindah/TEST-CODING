<?php

namespace App\Http\Controllers;

use App\Models\penyewa;
use App\Models\tukangsewa;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    function index()
   {
    return view('admin');
   }
   function tukangsewasewa()
   {
    $sewa = penyewa::all();
        return view('tukangsewa.sewa',compact('sewa'));

   }

   function tukangsewa_detailsewa($id)
   {

        $detailsewa = penyewa::join('users', 'users.id', '=', 'penyewa.user_id')
        ->join('tukangsewa','tukangsewa.kodemobil','=', 'penyewa.kodemobil')
        ->where('penyewa.id', $id)
        ->get(['users.name', 'users.email', 'users.nomer_tlp', 'users.alamat', 'users.nomer_sim',
                'tukangsewa.merekmobil', 'tukangsewa.modelmobil','tukangsewa.nomerplat',
                'penyewa.id','penyewa.user_id','penyewa.tanggal_mulai','penyewa.tanggal_kembali','penyewa.kodemobil', 'penyewa.sewaperhari', 'penyewa.total_hari',
                'penyewa.totalbayar','penyewa.status', 'penyewa.note'
            ]);

        return view('tukangsewa.detailsewa',compact('detailsewa'));
   }

   function tukangsewa_statussewa_edit(Request $request, $id)
   {
    $editstatus= [

        'status'=>$request->status,
        'note'=>$request->note,

    ];

    penyewa::where('id',$id) ->update($editstatus);
    return redirect()->to('/tukangsewa/sewa')->with('success','Berhasil update data');
   }



function penyewa_datamobil()
{
    $mobils = tukangsewa::where('status','Tersedia')->get();
    return view('penyewa.index',compact('mobils'));
} 
function search(Request $request)
    {
            $start_date = $request->input('start_date');
            $end_date = $request->input('end_date');
            
            $mobilIdsNotAvailable = penyewa::where('status','!=','Selesai')
             ->where(function($query) use ($start_date, $end_date) {
            $query->where('tanggal_mulai', '>=', $start_date) ->where('tanggal_kembali', '<=', $end_date);
            })->orWhere(function($query) use ($start_date, $end_date) {
            $query->where('tanggal_mulai', '<=', $start_date) ->where('tanggal_kembali', '>=', $end_date);
            })->orWhere(function($query) use ($start_date, $end_date) {
            $query->where('tanggal_mulai', '<=', $start_date) ->where('tanggal_kembali', '>=', $start_date) ->where('tanggal_kembali', '<=', $end_date);
            })->orWhere(function($query) use ($start_date, $end_date) {
            $query->where('tanggal_mulai', '>=', $start_date) ->where('tanggal_mulai', '<=', $end_date) ->where('tanggal_kembali', '>=', $end_date);
            })->pluck('kodemobil') ->toArray();
       
            $mobils = tukangsewa::where('status','Tersedia')->orWhere('status', $mobilIdsNotAvailable)
            ->whereNotIn('kodemobil', $mobilIdsNotAvailable)->get();
    return view('penyewa.index', compact('mobils'));
    }
function penyewa_sewa()
   {
    $user = Auth::user();
    $showsewa= penyewa::where('user_id',$user->id)->where('status', 'pengajuan','disewakan') ->get();
    //deklarasi variable $data mengambil data dari table users
    return view('penyewa.pengajuan',compact('showsewa'));

   }

   function penyewa_ajuansewa($kodemobil)
   {

        $user = Auth ::user();
        $usersewa= User ::where('id',$user->id)->get();  //mengambil data user berdasarkan id sesuai id user login

        $mobilsewa =tukangsewa ::where('kodemobil', $kodemobil)->first(); //mengambil data tukangsewa berdasrkan kodemobil yang dipilih

        return view('penyewa.formsewa',[
            'usersewa' => $usersewa,
            'mobilsewa' => $mobilsewa
        ]);

    }

    public function cari(Request $request)
    {
        $keyword = $request->input('keyword');

        $mobils = tukangsewa::where('merekmobil', 'LIKE', "%$keyword%")
                        ->orWhere('modelmobil', 'LIKE', "%$keyword%")
                        ->orWhere('status', 'LIKE', "%$keyword%")
                        ->get();

        return view('penyewa.index', compact('mobils'));
    }


    function penyewa_insertdatasewa(Request $request, $id)
    {

        $addsewa= [
            'kodemobil'=>$request->kodemobil,
            'user_id'=>$request->user_id,
            'tanggal_mulai' =>$request->tanggal_mulai,
            'tanggal_kembali' =>$request->tanggal_kembali,
            'total_hari'=>$request->total_hari,
            'sewaperhari'=>$request->sewaperhari,
            'totalbayar'=>$request->totalbayar,
            'status'=> $request->status,
            'note'=> $request->note

        ];

        penyewa::create($addsewa);
        return redirect()->to('admin/penyewa')->with('success','Berhasil Menambahkan Data!');
    }


    function hapus_ajuansewa($id)
    {
        penyewa::where('id',$id) ->DELETE();
        return redirect()->to('/penyewa/sewa')->with('success','Berhasil hapus data');
    }


    function penyewa_selesai()
   {
    $user = Auth::user();
    $showsewa= penyewa::where('user_id',$user->id)->where('status', 'selesai')->orWhere('status','pengembalian') ->get();

    //deklarasi variable $data mengambil data dari table users
    return view('penyewa.pengembalian',compact('showsewa'));

   }
   function penyewa_kembali($id)
   {

        $detailsewa2 = penyewa::join('users', 'users.id', '=', 'penyewa.user_id')
        ->join('tukangsewa','tukangsewa.kodemobil','=', 'penyewa.kodemobil')
        ->where('penyewa.id', $id)
        ->get(['users.name', 'users.email', 'users.nomer_tlp', 'users.alamat', 'users.nomer_sim',
                'tukangsewa.merekmobil', 'tukangsewa.modelmobil','tukangsewa.nomerplat',
                'penyewa.id','penyewa.user_id','penyewa.kodemobil', 'penyewa.sewaperhari', 'penyewa.total_hari',
                'penyewa.totalbayar','penyewa.status', 'penyewa.note'
            ]);

        return view('penyewa.formkembali',compact('detailsewa2'));
   }
   function penyewa_kembali2(Request $request, $id)
   {
    $editstatus= [

        'status'=>$request->status,
        'note'=>$request->note,

    ];

    penyewa::where('id',$id) ->update($editstatus);
    return redirect()->to('/penyewa/sewa')->with('success','Berhasil update data');
   }

}

<?php

namespace App\Http\Controllers;
use App\Models\User;
use Hash;
use Illuminate\Contracts\Hashing\Hasher;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash as FacadesHash;
use Illuminate\Validation\Rule;

class SesiController extends Controller
{
   function index()
   {

    return view('login');
   }
   function login(Request $request)
   {
    Session::flash('email', $request->email); // agar saat gagal login email tetap muncul
    $request->validate([
        'email' => 'required',
        'password' => 'required'
    ], [
        'email.required' => 'Email wajib diisi',
        'password.required' => 'Password wajib diisi',
    ]);  //validasi data agar semua kolom dalam form login terisi atau tidak kosong
    $infologin = [
        'email' => $request->email,
        'password' => $request->password
    ]; // mengecek apakah data yang di input saat login ini sesuai dengan value pada database atau tidak

    if (Auth::attempt($infologin)) {
        //role = '' adalah value di role table database
        if(Auth::user()->role =='tukangsewa')
        {
            return redirect('admin/tukangsewa');
        }
        elseif(Auth::user()->role =='penyewa')
        {
            return redirect('admin/penyewa');
        }

    } else {
        //jika salah
        return redirect('')->withErrors('Username dan password yang dimasukkan tidak valid');
    }
  }

   function logout()
   {
       Auth::logout();
       return redirect('')->with('success', 'Berhasil logout');
   }

   function register()
   {
    return view('register');
   }
   function create(Request $request)
   {
    Session::flash('name', $request->name);
    Session::flash('email', $request->email);
    Session::flash('alamat', $request->alamat);
    Session::flash('nomer_tlp', $request->nomer_tlp);
    Session::flash('nomer_sim', $request->nomer_sim);

    $request->validate([

        'email' => 'required|email|unique:users',
        'password' => 'required|min:6',
        'nomer_tlp' => 'required|min:11|max:12|unique:users',
        'nomer_sim' => 'required|min:12|max:12|unique:users',
    ],[
        'email.email' => 'Silakan masukan email yang valid',
        'email.unique' => 'email sudah pernah didaftarkan',
        'password.min' => 'minimum password 6 karakter',
        'nomer_tlp.min' => 'nomer telepon tidak valid',
        'nomer_tlp.max' => 'nomer telepon tidak valid',
        'nomer_tlp.unique' => 'no_tlp sudah pernah didaftarkan',
        'nomer_sim.min' => 'nomer SIM tidak valid',
        'nomer_sim.max' => 'nomer SIM tidak valid',
        'nomer_sim.unique' => 'no_tlp sudah pernah didaftarkan',


    ]);

    $data= [

        'name'=>$request->name,
        'email'=>$request->email,
        'password'=> FacadesHash::make($request->password),
        'role'=> $request->role?? 'tukangsewa','penyewa',
        'alamat'=>$request->alamat,
        'nomer_tlp'=>$request->nomer_tlp,
        'nomer_sim'=>$request->nomer_sim

    ];
    User::create($data);
    return redirect()->to('/')->with('success','Berhasil Register. Silakan Login!');

   }

   function profile()
   {
    $profile = Auth::user();
        //deklarasi variable $data mengambil data dari table users
        return view('profil.profile',compact('profile'));

   }

   function updateprofile(Request $request, $id )
   {

        Session::flash('name', $request->name);
        Session::flash('email', $request->email);
        Session::flash('alamat', $request->alamat);
        Session::flash('nomer_tlp', $request->nomer_tlp);
        Session::flash('nomer_sim', $request->nomer_sim);

        $edituser = User::where('id',$id)->firstOrFail();

        $request->validate([

            'email' => ['required','email', Rule::unique('users')->ignore($edituser->id) ],
            'nomer_tlp' => ['required','max:12','min:11', Rule::unique('users')->ignore($edituser->id) ],
            'nomer_sim' => ['required','max:14','min:12', Rule::unique('users')->ignore($edituser->id) ],
        ],[
            'email.email' => 'Silakan masukan email yang valid',
            'email.unique' => 'email sudah pernah didaftarkan',
            'nomer_tlp.min' => 'nomer telepon tidak valid',
            'nomer_tlp.max' => 'nomer telepon tidak valid',
            'nomer_tlp.unique' => 'nomer_tlp sudah pernah didaftarkan',
            'nomer_sim.min' => 'nomer SIM tidak valid',
            'nomer_sim.max' => 'nomer SIM tidak valid',
            'nomer_sim.unique' => 'nomer SIM sudah pernah didaftarkan',

        ]);

        $edituser->update($request->all());

        return redirect()->to('/profile')->with('success','Berhasil Mengubah Data!');
    }

    function updatepass(Request $request, $id ){
        Session::flash('password', $request->password);
        $editpaswd = User::where('id',$id)->firstOrFail();   
        $request->validate([
            'password' => ['required','min:6', Rule::unique('users')->ignore($editpaswd->id) ],
        ],[
            'password.min' => 'minimum password 6 karakter'
        ]);
                  
        $newpass =FacadesHash::make($request->password);      
          User::where('id',$id)->update(['password' => $newpass]);

        return redirect()->to('/profile')->with('success','Berhasil Mengubah password!');
     
    }

}

<?php

namespace App\Http\Controllers;

use App\Models\penyewa;
use App\Models\tukangsewa;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\Rule;

class tukangsewaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $showmobil = tukangsewa::orderBy('kodemobil','desc')->paginate(5); //pagination
        //deklarasi variable $data mengambil data dari table users
        return view('tukangsewa.index',compact('showmobil'));
        //'data' adalah parameter yang akan di panggil di index.blade.php


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tukangsewa.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Session ::flash('kodemobil', $request->kodemobil);
        Session::flash('merekmobil', $request->merekmobil);
        Session::flash('modelmobil', $request->modelmobil);
        Session::flash('nomerplat', $request->nomerplat);
        Session::flash('tarif', $request->tarif);

        $request->validate([

            'kodemobil' => 'required|numeric|unique:tukangsewa',
            'nomerplat' => 'required|min:4|max:8|unique:tukangsewa',
            'tarif' => 'required|numeric'
        ],[
            'kodemobil.unique' => 'kode sudah pernah didaftarkan',
            'nomerplat.min' => 'Nomer Plat tidak valid',
            'nomerplat.max' => 'Nomer Plat tidak valid',
            'nomerplat.unique' => 'Nomer Plat sudah pernah didaftarkan',

        ]);

        $addmobil= [
            'kodemobil'=>$request->kodemobil,
            'merekmobil'=>$request->merekmobil,
            'modelmobil'=>$request->modelmobil,
            'nomerplat'=>$request->nomerplat,
            'tarif'=>$request->tarif,
            'status'=> $request->status?? 'Tersedia','Tersewa','perawatan',

        ];

        tukangsewa::create($addmobil);
        return redirect()->to('admin/tukangsewa')->with('success','Berhasil Menambahkan Data!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $editdata =tukangsewa::where('kodemobil',$id)->first();
        return view('tukangsewa.edit')->with('editdata', $editdata);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $editdata = tukangsewa::where('kodemobil',$id)->firstOrFail();
        $request->validate([
            'nomerplat' => ['required','max:8','min:4', Rule::unique('tukangsewa')->ignore($editdata->id) ],
            'tarif' => 'required|numeric'
        ],[

            'nomerplat.min' => 'Nomer Plat tidak valid',
            'nomerplat.max' => 'Nomer Plat tidak valid',
            'nomerplat.unique' => 'Nomer Plat sudah pernah didaftarkan',

        ]);

        $editdata->update($request->all());
        return redirect()->to('admin/tukangsewa')->with('success','Berhasil Mengubah Data!');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        tukangsewa::where('kodemobil',$id) ->DELETE();
        return redirect()->to('admin/tukangsewa')->with('success','Berhasil hapus data');

    }

    

}

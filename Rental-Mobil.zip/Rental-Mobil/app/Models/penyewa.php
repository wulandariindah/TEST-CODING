<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class penyewa extends Model
{
    use HasFactory;

    protected $fillable = ['user_id', 'kodemobil', 'tanggal_mulai','tanggal_kembali','total_hari','sewaperhari', 'totalbayar','status', 'note'];
    protected $table = 'penyewa';

    public $timestamps =false;
}

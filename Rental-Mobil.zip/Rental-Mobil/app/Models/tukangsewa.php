<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tukangsewa extends Model
{
       use HasFactory;
    protected $fillable = ['kodemobil', 'merekmobil', 'modelmobil','nomerplat', 'tarif','status'];
    protected $table = 'tukangsewa';

    public $timestamps =false;
}

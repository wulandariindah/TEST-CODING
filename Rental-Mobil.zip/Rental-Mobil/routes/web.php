<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\OperatorController;
use App\Http\Controllers\PenyewaController;
use App\Http\Controllers\SesiController;
use App\Http\Controllers\SewaController;
use App\Http\Controllers\tukangsewaController;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::middleware(['guest'])->group(function(){ //yang bisa akses login dan index adalah orang yang belum login
    Route::get('/',[SesiController::class, 'index'])->name('login');
    Route::post('/',[SesiController::class, 'login'] );
    Route::get('/register',[SesiController::class, 'register'] );
    Route::post('/create',[SesiController::class, 'create'] );


});
Route::get('/home', function(){
    return redirect('/admin');
});

Route::middleware(['auth'])->group(function(){
    Route::get('/admin',[AdminController::class, 'index'] );
    Route::resource('/admin/operator', OperatorController::class  )->middleware('userAkses:operator');

    //menu tukangsewa
    Route::resource('/admin/tukangsewa',tukangsewaController::class )->middleware('userAkses:tukangsewa');
    Route::get('/tukangsewa/sewa',[AdminController::class, 'tukangsewasewa'])->middleware('userAkses:tukangsewa');
    Route::get('/tukangsewa/detailsewa/{id}',[AdminController::class, 'tukangsewa_detailsewa'])->middleware('userAkses:tukangsewa');
    Route::put('/tukangsewa/sewa/statusedit/{id}',[AdminController::class, 'tukangsewa_statussewa_edit'])->middleware('userAkses:tukangsewa');


    //menu penyewa
    Route::get('/admin/penyewa', [AdminController::class, 'penyewa_datamobil'])->middleware('userAkses:penyewa');
    Route::get('/penyewa/sewa',[AdminController::class, 'penyewa_sewa'])->middleware('userAkses:penyewa');
    Route::get('/penyewa/detailsewa/{kodemobil}',[AdminController::class, 'penyewa_ajuansewa'])->middleware('userAkses:penyewa');
    Route::post('/penyewa/addsewa/{kodemobil}',[AdminController::class, 'penyewa_insertdatasewa'])->middleware('userAkses:penyewa');
    Route::delete('/penyewa/delete_sewa/{id}',[AdminController::class, 'hapus_ajuansewa'])->middleware('userAkses:penyewa');
    Route::get('/penyewa/cari',[AdminController::class, 'search'])->middleware('userAkses:penyewa');Route::get('/penyewa/cari',[AdminController::class, 'search'])->middleware('userAkses:penyewa');
    Route::get('/penyewa/cari2',[AdminController::class, 'cari'])->middleware('userAkses:penyewa');
    Route::get('/penyewa/selesai',[AdminController::class, 'penyewa_selesai'])->middleware('userAkses:penyewa');
    Route::put('/penyewa/kembali/{id}',[AdminController::class, 'penyewa_kembali2'])->middleware('userAkses:penyewa');
    Route::get('/penyewa/pengembalian/{id}',[AdminController::class, 'penyewa_kembali'])->middleware('userAkses:penyewa');
    //all menu
    Route::get('/profile',[SesiController::class, 'profile'] );
    Route::put('/editprofile/{id}',[SesiController::class, 'updateprofile'] );
    Route::put('/editpass/{id}',[SesiController::class, 'updatepass'] );
    Route::get('/logout',[SesiController::class, 'logout'] );


});



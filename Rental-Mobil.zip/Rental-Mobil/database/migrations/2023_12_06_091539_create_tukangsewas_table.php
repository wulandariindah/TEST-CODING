<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTukangsewasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tukangsewa', function (Blueprint $table) {
            $table->id();
            $table->integer('kodemobil');
            $table->unique('kodemobil');
            $table->string('merekmobil');
            $table->string('modelmobil');
            $table->string('nomerplat');
            $table->string('tarif');
            $table->enum('status', ['Tersedia','Tersewa', 'Perawatan']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tukangsewa');
    }
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Penyewa extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('penyewa', function (Blueprint $table) {
            $table->id();
            $table->integer('user_id');
            $table->integer('mobil_id');
            $table->integer('total_hari');
            $table->integer('sewaperhari');
            $table->integer('totalbayar');
            $table->enum('status', ['Pengajuan','Disewakan', 'Tolak', 'Selesai']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}

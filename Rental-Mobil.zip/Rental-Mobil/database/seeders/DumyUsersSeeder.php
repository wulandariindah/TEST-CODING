<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class DumyUsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $usersData = [
        [
            'name'=>'mas Tukang sewa',
            'email'=>'Tukang-sewa1@gmail.com',
            'role'=>'tukangsewa',
            'password'=>bcrypt('654321'),
            'alamat'=>'pejagoan Kebumen',
            'nomer_tlp'=>'082111222333',
            'nomer_sim'=>'87654321'
        ],
        [
            'name'=>'mas penyewa',
            'email'=>'penyewa1@gmail.com',
             'role'=>'penyewa',
            'password'=>bcrypt('222222'),
            'alamat'=>'sempor Kebumen',
            'nomer_tlp'=>'081333444555',
            'nomer_sim'=>'56781234'

        ],
    ];
    foreach($usersData as $key => $val){
       User::create($val);  //memasukan data data ke kolom table user -> $usersData
    }
    }
}
